<div class="top-nav">
			<ul>
				<li><a href="index.php?action=samsung">Samsung</a></li>
				<li><a href="index.php?action=oppo">Oppo</a></li>
				<li><a href="index.php?action=htc">HTC</a></li>
				<li><a href="index.php?action=apple">Apple</a></li>
				<li><a href="index.php?action=sony">Sony</a></li>
			</ul>
		</div>