<div class="content">
		    	<div class="top-3-grids">
		    		<div class="section group">
				<div class="grid_1_of_3 images_1_of_3">
					<a href="index.php?action=liststore"><img src="images/grid-img1.jpg"><h3>LIST PRODUCTS</h3></a>
				</div>
				<div class="grid_1_of_3 images_1_of_3 second">
					<a href="index.php?action=addproducts"><img src="images/grid-img2.jpg"><h3>ADD PRODUCTS</h3></a>  
				</div>
				<div class="grid_1_of_3 images_1_of_3 theree">
					<a href="index.php?action=adduser"><img src="images/grid-img3.jpg"><h3>ADD USER</h3></a>					  
				</div>
			</div>