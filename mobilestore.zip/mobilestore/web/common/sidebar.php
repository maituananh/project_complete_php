<div class="content-sidebar" style="float:right;margin-top: -950px;/* position: absolute; */position: absolute;/* float: right; */margin-left: 950px;">
		    		<h4>Products</h4>
						<ul>
							<li><a href="#">Oppo</a></li>
							<li><a href="#">Samsung</a></li>
							<li><a href="#">Sony</a></li>
							<li><a href="#">Nokia</a></li>
							<li><a href="#">Apple</a></li>
							<li><a href="#">Blackberry</a></li>
							<li><a href="#">HTC</a></li>
						</ul>
				</div>
				<!--style="float:right;margin-top: -950px;/* position: absolute; */position: absolute;/* float: right; */-->