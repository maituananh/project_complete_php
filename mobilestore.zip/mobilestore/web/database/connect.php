<?php
$connect = mysqli_connect('localhost', 'root', '', 'leoshop');
?>