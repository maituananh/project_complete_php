<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Page Title</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" media="screen" href="main.css" />
	<script src="main.js"></script>
</head>
<body>
	<div class="error-page" style="float:left; margin-left:200px">
	<h3>404</h3>
	<h3>A Page Not Found 404 error occurred</h3>
	<h3>UserName or Password Not Found</h3>
	<h2><a href='../../index.php'>return login</a></h2>
</div>
</body>
</html>