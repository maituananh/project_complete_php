<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class buyproducts extends Model
{
    public $table = 'buyproducts';
    public $guarded = [];
}