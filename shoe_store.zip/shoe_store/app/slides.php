<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class slides extends Model
{
    public $table = 'slides';
    public $guarded = [];
}