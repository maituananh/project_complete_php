<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class products extends Model
{
    public $table = 'products';
    public $guarded = [];
}