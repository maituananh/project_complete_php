<?php $__env->startSection('content'); ?>

<div class="index-banner">
    <div class="wmuSlider example1" style="height: 560px;">
        <div class="wmuSliderWrapper">
            <article style="position: relative; width: 100%; opacity: 1;">
                <div class="banner-wrap">
                    <div class="slider-left">
                        <img src="<?php echo e(URL::asset('image/banner1.jpg')); ?>" alt="" />
                    </div>
                    <div class="slider-right">
                        <h1>Classic</h1>
                        <h2>White</h2>
                        <p>Lorem ipsum dolor sit amet</p>
                        <div class="btn"><a href="shop.html">Shop Now</a></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </article>
            <article style="position: absolute; width: 100%; opacity: 0;">
                <div class="banner-wrap">
                    <div class="slider-left">
                        <img src="<?php echo e(URL::asset('image/banner2.jpg')); ?>" alt="" />
                    </div>
                    <div class="slider-right">
                        <h1>Classic</h1>
                        <h2>White</h2>
                        <p>Lorem ipsum dolor sit amet</p>
                        <div class="btn"><a href="shop.html">Shop Now</a></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </article>
            <article style="position: absolute; width: 100%; opacity: 0;">
                <div class="banner-wrap">
                    <div class="slider-left">
                        <img src="<?php echo e(URL::asset('image/banner1.jpg')); ?>" alt="" />
                    </div>
                    <div class="slider-right">
                        <h1>Classic</h1>
                        <h2>White</h2>
                        <p>Lorem ipsum dolor sit amet</p>
                        <div class="btn"><a href="shop.html">Shop Now</a></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </article>
            <article style="position: absolute; width: 100%; opacity: 0;">
                <div class="banner-wrap">
                    <div class="slider-left">
                        <img src="<?php echo e(URL::asset('image/banner2.jpg')); ?>" alt="" />
                    </div>
                    <div class="slider-right">
                        <h1>Classic</h1>
                        <h2>White</h2>
                        <p>Lorem ipsum dolor sit amet</p>
                        <div class="btn"><a href="shop.html">Shop Now</a></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </article>
            <article style="position: absolute; width: 100%; opacity: 0;">
                <div class="banner-wrap">
                    <div class="slider-left">
                        <img src="image/banner1.jpg" alt="" />
                    </div>
                    <div class="slider-right">
                        <h1>Classic</h1>
                        <h2>White</h2>
                        <p>Lorem ipsum dolor sit amet</p>
                        <div class="btn"><a href="shop.html">Shop Now</a></div>
                    </div>
                    <div class="clear"></div>
                </div>
            </article>
        </div>
        <a class="wmuSliderPrev">Previous</a><a class="wmuSliderNext">Next</a>
        <ul class="wmuSliderPagination">
            <li><a href="#" class="">0</a></li>
            <li><a href="#" class="">1</a></li>
            <li><a href="#" class="wmuActive">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
        </ul>
        <a class="wmuSliderPrev">Previous</a><a class="wmuSliderNext">Next</a>
        <ul class="wmuSliderPagination">
            <li><a href="#" class="wmuActive">0</a></li>
            <li><a href="#" class="">1</a></li>
            <li><a href="#" class="">2</a></li>
            <li><a href="#" class="">3</a></li>
            <li><a href="#" class="">4</a></li>
        </ul>
    </div>
    <script src="<?php echo e(URL::asset('js/jquery.wmuSlider.js')); ?>"></script>
    <script>
        $('.example1').wmuSlider();
    </script>
</div>



<div class="main">
    <div class="wrap">
        <div class="content-top">
            <div class="clear"></div>
        </div>

        <div class="content-bottom">
            <div class="box1">

                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col_1_of_3 span_1_of_3" style="margin-left:0px; margin-right:43px; height:353px;">
                <a href="http://localhost/shoe_store/public/single/<?php echo e($item->idProducts); ?>/<?php echo e($item->name); ?>/<?php echo e($item->price); ?>/<?php echo e($item->image); ?>/<?php echo e($item->category); ?>/<?php echo e($item->describe); ?>/<?php echo e($item->content_details); ?>/<?php echo e($item->reviews); ?>/<?php echo e($item->created_at); ?>">
                        <div class="view view-fifth">
                            <div class="top_box" style="height: auto">
                                <h3 class="m_1">
                                    <?php echo e($item->name); ?>

                                </h3>
                                <p class="m_2">
                                    <?php echo e($item->category); ?>

                                </p>
                                <div class="grid_img">
                                <div class="css3"><img src="<?php echo e(URL::asset('image')); ?>/<?php echo e($item->image); ?>" alt="" /></div>
                                    <div class="mask">
                                        <div class="info">Quick View</div>
                                    </div>
                                </div>
                                <div class="price">$
                                    <?php echo e($item->price); ?> .000
                                </div>
                            </div>
                        </div>
                        <span class="rating" style="width:50%; ">
                            <input type="radio" class="rating-input" id="rating-input-1-5" name="rating-input-1">
                            <label for="rating-input-1-5" class="rating-star1"></label>
                            <input type="radio" class="rating-input" id="rating-input-1-4" name="rating-input-1">
                            <label for="rating-input-1-4" class="rating-star1"></label>
                            <input type="radio" class="rating-input" id="rating-input-1-3" name="rating-input-1">
                            <label for="rating-input-1-3" class="rating-star1"></label>
                            <input type="radio" class="rating-input" id="rating-input-1-2" name="rating-input-1">
                            <label for="rating-input-1-2" class="rating-star"></label>
                            <input type="radio" class="rating-input" id="rating-input-1-1" name="rating-input-1">
                            <label for="rating-input-1-1" class="rating-star"></label>&nbsp;
                            (<?php echo e($item->like); ?>)
                        </span>
                        <ul class="list">
                            <li>
                                <img src="<?php echo e(URL::asset('image/plus.png')); ?>" alt="" />
                                <ul class="icon1 sub-icon1 profile_img">
                                    <?php if(Session::get("username") != ""): ?>
                                        <a style="margin-button:1px; height: 31.5px" class="active-icon c1" href="single/buyProductnow/<?php echo e($item->idProducts); ?>">BUY NOW</a>
                                    <?php else: ?>
                                        <a style="margin-button:1px; height: 31.5px" class="active-icon c1" href="/shoe_store/public/login">NEED LOGIN</a>   
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                        <div class="clear"></div>
                    </a>
                </div>
                
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clear"></div>
                </a>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>