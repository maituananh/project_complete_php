<?php $__env->startSection('menu'); ?>
<!-- start header menu -->
<ul class="megamenu skyblue">
    <li><a class="color1" href="http://localhost/shoe_store/public/">Home</a></li>
    <li class="grid"><a class="color2" href="#">Men</a>
        <div class="megapanel">
            <div class="row">
                <div class="col1">
                    <div class="h_nav">
                        <h4>popular</h4>
                        <ul>
                            <li><a href="shop.html">new arrivals</a></li>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">login</a></li>
                        </ul>
                    </div>

                </div>
                <div class="col1">
                    <div class="h_nav">
                        <h4>style zone</h4>
                        <ul>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">brands</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <img src="<?php echo e(URL::asset('image/nav_img.jpg')); ?>" alt="" />
            </div>
        </div>
    </li>
    <li class="active grid"><a class="color4" href="#">Women</a>
        <div class="megapanel">
            <div class="row">
                <div class="col1">
                    <div class="h_nav">
                        <h4>shop</h4>
                        <ul>
                            <li><a href="shop.html">new arrivals</a></li>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">brands</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1">
                    <div class="h_nav">
                        <h4>help</h4>
                        <ul>
                            <li><a href="shop.html">trends</a></li>
                            <li><a href="shop.html">sale</a></li>
                            <li><a href="shop.html">style videos</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">style videos</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1">
                    <div class="h_nav">
                        <h4>my company</h4>
                        <ul>
                            <li><a href="shop.html">trends</a></li>
                            <li><a href="shop.html">sale</a></li>
                            <li><a href="shop.html">style videos</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">style videos</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1">
                    <div class="h_nav">
                        <h4>account</h4>
                        <ul>
                            <li><a href="shop.html">login</a></li>
                            <li><a href="shop.html">create an account</a></li>
                            <li><a href="shop.html">create wishlist</a></li>
                            <li><a href="shop.html">my shopping bag</a></li>
                            <li><a href="shop.html">brands</a></li>
                            <li><a href="shop.html">create wishlist</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1">
                    <div class="h_nav">
                        <h4>popular</h4>
                        <ul>
                            <li><a href="shop.html">new arrivals</a></li>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">style videos</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1">
                    <div class="h_nav">
                        <img src="<?php echo e(URL::asset('image/nav_img1.jpg')); ?>" alt="" />
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col2"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
            </div>
        </div>
    </li>
    <li><a class="color5" href="#">Kids</a>
        <div class="megapanel">
            <div class="row">
                <div class="col1">
                    <div class="h_nav">
                        <h4>popular</h4>
                        <ul>
                            <li><a href="shop.html">new arrivals</a></li>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">login</a></li>
                        </ul>
                    </div>

                </div>
                <div class="col1">
                    <div class="h_nav">
                        <h4>style zone</h4>
                        <ul>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">brands</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <img src="<?php echo e(URL::asset('image/nav_img2.jpg')); ?>" alt="" />
            </div>
        </div>
    </li>
    <li><a class="color6" href="#">Sale</a>
        <div class="megapanel">
            <div class="row">
                <div class="col1">
                    <div class="h_nav">
                        <h4>shop</h4>
                        <ul>
                            <li><a href="shop.html">new arrivals</a></li>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">brands</a></li>
                        </ul>
                    </div>

                </div>

                <div class="col1">
                    <div class="h_nav">
                        <h4>help</h4>
                        <ul>
                            <li><a href="shop.html">trends</a></li>
                            <li><a href="shop.html">sale</a></li>
                            <li><a href="shop.html">style videos</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">style videos</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col1">
                    <div class="h_nav">
                        <h4>account</h4>
                        <ul>
                            <li><a href="shop.html">login</a></li>
                            <li><a href="shop.html">create an account</a></li>
                            <li><a href="shop.html">create wishlist</a></li>
                            <li><a href="shop.html">my shopping bag</a></li>
                            <li><a href="shop.html">brands</a></li>
                            <li><a href="shop.html">create wishlist</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col1">
                    <div class="h_nav">
                        <h4>popular</h4>
                        <ul>
                            <li><a href="shop.html">new arrivals</a></li>
                            <li><a href="shop.html">men</a></li>
                            <li><a href="shop.html">women</a></li>
                            <li><a href="shop.html">accessories</a></li>
                            <li><a href="shop.html">kids</a></li>
                            <li><a href="shop.html">style videos</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col2"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
            </div>
        </div>
    </li>
    <li>
        <a class="color9" style="color:white" href="/shoe_store/public/logout">LogOut</a>
    </li>
    <li><a class="color10" href="/shoe_store/public/admin/addProducts">Add Products</a></li>
    <li><a class="color10" href="/shoe_store/public/admin/ListProducts">List Products</a></li>
    <li><a class="color10" href="/shoe_store/public/admin/ListUsers">List Users</a></li>
</ul>
<div class="clear"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>