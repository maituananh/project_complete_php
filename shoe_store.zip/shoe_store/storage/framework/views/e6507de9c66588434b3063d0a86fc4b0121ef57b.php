<?php $__env->startSection('content'); ?>

<div class="index-banner">
    
</div>

<div class="main">
    <div class="wrap">
        <div class="content-top">
            <div class="lsidebar span_1_of_c1">

            </div>
            <div class="cont span_2_of_c1">

                <div class="clear"> </div>
            </div>
            <div class="clear"></div>
        </div>

        <div class="content-bottom">
            <div class="table">
                    <table border="1px">
                            <tr>
                                <th>UsersName</th>
                                <th>NameProducts</th>
                                <th>Price</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <td><?php echo e($item->name_Users); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td><img src="<?php echo e(URL::asset('image')); ?>/<?php echo e($item->image); ?>" alt="" /></td>
                            <td><a href="deleteBag/<?php echo e($item->id); ?>">DELETE</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
            <div class="clear"></div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>