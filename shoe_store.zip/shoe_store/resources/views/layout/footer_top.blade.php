<div class="footer-top">
    <div class="wrap">
        <div class="col_1_of_footer-top span_1_of_footer-top">
            <ul class="f_list">
                <li><img src="{{URL::asset('image/f_icon.png')}}" alt="" /><span class="delivery">Free
                        delivery on all
                        orders over £100*</span></li>
            </ul>
        </div>
        <div class="col_1_of_footer-top span_1_of_footer-top">
            <ul class="f_list">
                <li><img src="{{URL::asset('image/f_icon1.png')}}" alt="" /><span class="delivery">Customer
                        Service :<span class="orange"> (800) 000-2587 (freephone)</span></span></li>
            </ul>
        </div>
        <div class="col_1_of_footer-top span_1_of_footer-top">
            <ul class="f_list">
                <li><img src="{{URL::asset('image/f_icon2.png')}}" alt="" /><span class="delivery">Fast
                        delivery & free
                        returns</span></li>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
</div>