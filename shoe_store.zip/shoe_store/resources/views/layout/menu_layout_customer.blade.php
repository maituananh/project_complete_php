

<!-- start header menu -->
<ul class="megamenu skyblue">
    <li>
        <a class="color1" href="http://localhost/shoe_store/public/">Home</a>
    </li>
    <li class="grid">
        <a class="color2" href="/shoe_store/public/countProducts">Top Sell</a>
    </li>
    <li class="grid">
        <a class="color3" href="/shoe_store/public/kind/new">New</a>
    </li>
    <li class="active grid">
        <a class="color4" href="/shoe_store/public/kind/adidas">Adidas</a>
    </li>
    <li>
        <a class="color5" href="/shoe_store/public/kind/converse">Converse</a>
    </li>
    <li>
        <a class="color6" href="/shoe_store/public/kind/nike">Nike</a>
    </li>
    <li>
        <a class="color9" style="color:white" href="/shoe_store/public/logout">LogOut</a>
    </li>
</ul>
<div class="clear"></div>