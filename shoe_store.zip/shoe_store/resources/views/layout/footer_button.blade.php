<div class="footer-bottom">
        <div class="wrap">
            <div class="section group">
                <div class="col_1_of_5 span_1_of_5">
                    <h3 class="m_9"> Shop' information</h3>
                    <ul class="sub_list">

                        <li><a href="https://www.google.com/search?q=459+t%C3%B4n+%C4%91%E1%BB%A9c+th%E1%BA%AFng&npsic=0&rflfq=1&rlha=0&rllag=16062403,108158984,24&tbm=lcl&ved=2ahUKEwjbo4SLmNnfAhXaA4gKHfaWADYQtgN6BAgBEAQ&tbs=lrf:!2m1!1e2!3sIAE,lf:1,lf_ui:2&rldoc=1#rlfi=hd:;si:1949532313718834535;mv:!1m2!1d16.0625306!2d108.1592068!2m2!1d16.0622762!2d108.15876259999999">Address: 455 Tôn Đức Thắng, Liên Chiểu</a></li>
                        <li><a a href="">Hotline: 09098888</a></li>
                    </ul>

                </div>
                <div class="col_1_of_5 span_1_of_5">
                    <h3 class="m_9">More</h3>
                    <ul class="list1">
                        <li><a>Uy tín và chất lượng</a></li>
                        <li><a>Cam kết thông tin chính xác</a></li>
                        <li><a>Cam kết chính hãng</a></li>
                        <li><a>Đổi trả trong vòng 3 ngày</a></li>
                    </ul>
                </div>
                <div class="col_1_of_5 span_1_of_5">
                    <h3 class="m_9">Support</h3>
                    <ul class="list1">
                        <li><a href="">Các hình thức thanh toán</a></li>
                        <li><a href="">Hỗ trợ vận chuyển</a></li>
                        <li><a href="">Tư vấn khách hàng</a></li>
                        <li><a href="">Chính sách bảo hành</a></li>
                    </ul>
                </div>
                <div class="col_1_of_5 span_1_of_5">
                    <h3 class="m_9">Author's </h3>
                    <ul class="list1">
                        <li><a>Mai Tuấn Anh</a></li>
                        <li><a>Bùi Thị Như Ngọc</a></li>
                        <li><a>Lê Thị Kim Phượng</a></li>
                        <li><a>Nguyễn Thị Thu Uyên</a></li>
                    </ul>
                </div>
                <div class="col_1_of_5 span_1_of_5">
                    <h3 class="m_9">Theo dõi</h3>
                    <ul class="list1">
                        <li><a href="shop.html">Facebook</a></li>
                        <li><a href="shop.html">Instagram</a></li>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>